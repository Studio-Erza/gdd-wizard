To use GDD Wizard, simply run the GDD_Wizard.html file. it works offline in chromium browsers. Tested using Google Chrome.

Para usar GDD Wizard, simplemente ejecuta el archivo GDD_Wizard.html. Funciona sin conexión en navegadores basados en Chromium. Probado con Google Chrome.

Pour utiliser GDD Wizard, exécutez simplement le fichier GDD_Wizard.html. Il fonctionne hors ligne dans les navigateurs Chromium. Testé avec Google Chrome.

Para usar o GDD Wizard, basta executar o arquivo GDD_Wizard.html. Ele funciona offline em navegadores Chrome. Testado no Google Chrome.

Um den GDD Wizard zu verwenden, führen Sie einfach die Datei GDD_Wizard.html aus. Er funktioniert offline in Chromium-Browsern. Getestet mit Google Chrome.